import PySimpleGUI as sg
import qrcode
from PIL import ImageColor

sg.theme('purple')

qr_colors = ['red', 'yellow', 'green', 'blue', 'pink', 'violet', 'brown', 'cyan']

layout = [
    [sg.Text('To generate QR code, ENTER TEXT:')],
    [sg.InputText()],
    [sg.Text('Select QR code fill color:')],
    [sg.OptionMenu(qr_colors, default_value='black', key='fill_color')],
    [sg.Text('Select QR code background color:')],
    [sg.OptionMenu(qr_colors, default_value='white', key='back_color')],
    [sg.Button('Create QR code'), sg.Button('Exit')]
]

window = sg.Window('QR Code Generator', layout)

while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED or event == 'Exit':
        break
    elif event == 'Create QR code':
        text = values[0]
        if text.strip():
            fill_color = values['fill_color']
            back_color = values['back_color']
            fill_color = ImageColor.getrgb(fill_color)
            back_color = ImageColor.getrgb(back_color)
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(text)
            qr.make(fit=True)
            img = qr.make_image(fill_color=fill_color, back_color=back_color)
            print(f"Fill color: {fill_color}")
            print(f"Background color: {back_color}")
            
            img_file = 'qrcode.png'
            img.save(img_file)
            sg.popup('QR code generated!', image=img_file)
        else:
            sg.popup_error('Please enter some text')

window.close()
